from django.urls import path,include
from rest_framework.routers import DefaultRouter
from .views import car_mechanicViewSets

router =DefaultRouter()

router.register(r'car_mechanic', car_mechanicViewSets,basename='car_mechanic'),

urlpatterns=[
   path ('',include(router.urls)),
]