from django.contrib import admin
from .models import car_mechanic

admin.site.register(car_mechanic)
 