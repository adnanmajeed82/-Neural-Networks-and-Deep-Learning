from django.shortcuts import render
from rest_framework import viewsets
from .models import car_mechanic
from .serializers import car_mechanicSerializer
# Create your views here.

class car_mechanicViewSets(viewsets.ModelViewSet):
    queryset=car_mechanic.objects.all()
    serializer_class=car_mechanicSerializer