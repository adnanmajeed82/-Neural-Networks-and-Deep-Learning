from django.apps import AppConfig


class OnwheelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'onwheel'
