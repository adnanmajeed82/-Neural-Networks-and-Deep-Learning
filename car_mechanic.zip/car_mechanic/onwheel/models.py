from django.db import models

# Create your models here.
class car_mechanic(models.Model):
    name=models.CharField(max_length=30)
    phone=models.IntegerField()
    location_service=models.TextField()

    def __str__(self):
        return self.name 