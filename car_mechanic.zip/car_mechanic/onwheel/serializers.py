from .models import car_mechanic
from rest_framework import serializers

class car_mechanicSerializer(serializers.ModelSerializer):
    class Meta:
        model=car_mechanic
        fields='__all__'